# TradeHost VPS website starter

A responsive, original front-end website concept for an MT5 VPS hosting business.

## Open on Android
1. Download and extract `tradehost_vps.zip`.
2. Open `index.html` in a browser, or upload the folder to a static host such as GitHub Pages or Netlify.
3. Edit `index.html` and `style.css` to change branding, plan details and contact information.

## Important before launch
- This is a front-end template only. It does not provision VPS servers, create customer accounts, connect to MetaTrader, or accept payments.
- Pricing, server specifications, uptime and dashboard metrics are illustrative placeholders. Replace them with verified details before publishing.
- The contact email uses a reserved `.example` address. Replace it with your real business email.
- For production, add a secure backend, authentication, payment provider integration, server provisioning, monitoring, support workflow, privacy policy and terms.
- Never collect a customer's broker password or trading credentials through this static site.
- Do not promise profits or a guaranteed win rate.
